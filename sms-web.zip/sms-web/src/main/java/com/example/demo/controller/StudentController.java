package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.modal.Student;
import com.example.demo.service.StudentService;

@RestController
@RequestMapping(value = "smscloud")
public class StudentController {
	
	@Autowired
	StudentService studentservice;
	
	//@RequestMapping(value = "hello")
//	public String greeting(@RequestParam String name)
//	{
//		return "Hello from spring boot to "+ name;
//		
//	}
	
	@RequestMapping(value = "student", method = RequestMethod.POST)
	public Student save(@RequestBody Student student)
	{
		System.out.println(student.getName());
		studentservice.save(student);
		return student;
	}
	
//	@RequestMapping(value = "student", method = RequestMethod.GET)
//	public List<Student> fecth()
//	{
		
//		return studentservice.fetch();
//	}

}
