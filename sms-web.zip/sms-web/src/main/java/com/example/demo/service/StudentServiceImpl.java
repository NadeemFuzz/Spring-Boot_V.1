package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.modal.Student;
import com.example.demo.service.repository.StudentRepository;
@Service
public class StudentServiceImpl implements StudentService{

	@Autowired
	StudentRepository studentrepository;
	
	@Override
	public Student save(Student student) {
		
		return studentrepository.save(student);
	}

	@Override
	public Student fetch() {
		
		return null;
	}

	@Override
	public Student fetch(Student student) {
		
		return null;
	}
	
	

}
