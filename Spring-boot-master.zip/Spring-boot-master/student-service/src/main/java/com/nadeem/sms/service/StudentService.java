package com.nadeem.sms.service;

import com.nadeem.sms.model.Student;

public interface StudentService {

	Student save(Student student);
	Student fetch();
	Student fetch(Student student);
}
