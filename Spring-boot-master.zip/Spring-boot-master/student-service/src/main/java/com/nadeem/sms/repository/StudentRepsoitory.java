package com.nadeem.sms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nadeem.sms.model.Student;

public interface StudentRepsoitory extends JpaRepository<Student, Integer>{

}
